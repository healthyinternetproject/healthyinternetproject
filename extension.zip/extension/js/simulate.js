
jQuery(document).ready(function ($) {
	
	//document.querySelector('[name="accurate"][data-score="2"]').click();

});